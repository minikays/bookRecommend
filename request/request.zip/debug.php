<?php
$con = mysql_connect("localhost", "root", "ab7df0e4e6");
		if (!$con)
		{
			die('Could not connect: ' . mysql_error());
			echo "wrong";
		}	
		else
			echo "yes";
		
		//选择成长轨的数据库
		$db_selected = mysql_select_db("growthtrack",$con);
		echo "1";
		$sql = "select * from users where sid = '11331257'";
		echo "2";
		$result = mysql_query($sql,$con);
		echo "3";
		if($result==false)
			echo "haha";
		$result=mysql_fetch_array($result);
		echo $result["password"];
?>